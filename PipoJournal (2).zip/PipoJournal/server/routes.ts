import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertChatMessageSchema, insertReminderSchema, insertTodoSchema, insertCalendarEventSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // Get current user (demo user for now)
  app.get("/api/user/current", async (req, res) => {
    try {
      const user = await storage.getUser("default-user");
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to get user" });
    }
  });

  // Get chat messages
  app.get("/api/chat/messages", async (req, res) => {
    try {
      const messages = await storage.getChatMessages("default-user");
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to get chat messages" });
    }
  });

  // Send chat message
  app.post("/api/chat/messages", async (req, res) => {
    try {
      const validatedData = insertChatMessageSchema.parse({
        ...req.body,
        userId: "default-user",
      });

      const userMessage = await storage.createChatMessage(validatedData);

      // Check for automatic reminder/calendar creation
      const autoCreations = await processAutoCreations(validatedData.content);

      // Extract and track names from the message
      await extractAndTrackNames(validatedData.content, "default-user");

      // Generate Pipo's response
      const pipoResponse = generatePipoResponse(validatedData.content, autoCreations);
      const pipoMessage = await storage.createChatMessage({
        userId: "default-user",
        content: pipoResponse,
        isFromPipo: true,
        messageType: "text",
      });

      res.json({ 
        userMessage, 
        pipoMessage,
        autoCreations: autoCreations
      });
    } catch (error) {
      res.status(400).json({ message: "Failed to send message" });
    }
  });

  // Get reminders
  app.get("/api/reminders", async (req, res) => {
    try {
      const reminders = await storage.getReminders("default-user");
      res.json(reminders);
    } catch (error) {
      res.status(500).json({ message: "Failed to get reminders" });
    }
  });

  // Create reminder
  app.post("/api/reminders", async (req, res) => {
    try {
      const validatedData = insertReminderSchema.parse({
        ...req.body,
        userId: "default-user",
      });

      const reminder = await storage.createReminder(validatedData);
      res.json(reminder);
    } catch (error) {
      res.status(400).json({ message: "Failed to create reminder" });
    }
  });

  // Update reminder
  app.patch("/api/reminders/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const reminder = await storage.updateReminder(id, req.body);
      
      if (!reminder) {
        return res.status(404).json({ message: "Reminder not found" });
      }
      
      res.json(reminder);
    } catch (error) {
      res.status(400).json({ message: "Failed to update reminder" });
    }
  });

  // Get todos
  app.get("/api/todos", async (req, res) => {
    try {
      const todos = await storage.getTodos("default-user");
      res.json(todos);
    } catch (error) {
      res.status(500).json({ message: "Failed to get todos" });
    }
  });

  // Create todo
  app.post("/api/todos", async (req, res) => {
    try {
      const validatedData = insertTodoSchema.parse({
        ...req.body,
        userId: "default-user",
      });

      const todo = await storage.createTodo(validatedData);
      res.json(todo);
    } catch (error) {
      res.status(400).json({ message: "Failed to create todo" });
    }
  });

  // Update todo
  app.patch("/api/todos/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const todo = await storage.updateTodo(id, req.body);
      
      if (!todo) {
        return res.status(404).json({ message: "Todo not found" });
      }
      
      res.json(todo);
    } catch (error) {
      res.status(400).json({ message: "Failed to update todo" });
    }
  });

  // Get calendar events
  app.get("/api/calendar/events", async (req, res) => {
    try {
      const events = await storage.getCalendarEvents("default-user");
      res.json(events);
    } catch (error) {
      res.status(500).json({ message: "Failed to get calendar events" });
    }
  });

  // Create calendar event
  app.post("/api/calendar/events", async (req, res) => {
    try {
      const validatedData = insertCalendarEventSchema.parse({
        ...req.body,
        userId: "default-user",
      });

      const event = await storage.createCalendarEvent(validatedData);
      res.json(event);
    } catch (error) {
      res.status(400).json({ message: "Failed to create calendar event" });
    }
  });

  return httpServer;
}

interface AutoCreation {
  type: 'reminder' | 'calendar' | 'todo';
  title: string;
  description?: string;
  dueDate?: Date;
  startTime?: Date;
  endTime?: Date;
  created: boolean;
}

async function processAutoCreations(userMessage: string): Promise<AutoCreation[]> {
  const creations: AutoCreation[] = [];
  const lowerMessage = userMessage.toLowerCase();
  
  console.log('🎯 Processing message for auto-creation:', userMessage);
  console.log('🎯 Lowercase message:', lowerMessage);

  // Detect reminders - enhanced patterns for better recognition
  const reminderPatterns = [
    /remind me to (.+?)(?:\s+(?:at|on|in|by|around)\s+(.+?))?(?:\s|$)/i,
    /don't forget to (.+?)(?:\s+(?:at|on|in|by|around)\s+(.+?))?(?:\s|$)/i,
    /i need to remember to (.+?)(?:\s+(?:at|on|in|by|around)\s+(.+?))?(?:\s|$)/i,
    /make sure i (.+?)(?:\s+(?:at|on|in|by|around)\s+(.+?))?(?:\s|$)/i,
    /set (?:a\s+)?(?:reminder|alarm) (?:to\s+)?(.+?)(?:\s+(?:at|on|in|by|for|around)\s+(.+?))?(?:\s|$)/i,
    /(?:reminder|alarm) for (.+?)(?:\s+(?:at|on|in|by|around)\s+(.+?))?(?:\s|$)/i,
    // Task-specific patterns
    /(?:do|finish|complete|work on|study for|prepare for) (?:my\s+)?(?:homework|assignment|test|exam|chores?|cleaning|laundry|shopping|groceries) (.*)(?:\s+(?:at|on|in|by|around)\s+(.+?))?(?:\s|$)/i,
    /i have (?:to\s+)?(?:do|finish|complete|work on|study for|prepare for) (?:my\s+)?(.+?)(?:\s+(?:at|on|in|by|around)\s+(.+?))?(?:\s|$)/i,
    // Hobby and leisure activity patterns
    /(?:play|go|do|practice|enjoy|have fun) (?:with\s+)?(?:some\s+)?(?:basketball|football|soccer|tennis|golf|baseball|volleyball|swimming|running|jogging|cycling|hiking|yoga|gym|workout|exercise) (.*)(?:\s+(?:at|on|in|by|around)\s+(.+?))?(?:\s|$)/i,
    /(?:play|game|gaming) (?:session\s+)?(?:with\s+)?(.+?)(?:\s+(?:at|on|in|by|around)\s+(.+?))?(?:\s|$)/i,
    /(?:read|reading|finish reading) (?:a\s+|the\s+|my\s+)?(?:book|novel|magazine|article) (.*)(?:\s+(?:at|on|in|by|around)\s+(.+?))?(?:\s|$)/i,
    /(?:chill|relax|hang out|spend time) (?:at\s+|in\s+)?(?:the\s+|a\s+)?(?:cafe|coffee shop|restaurant|park|library|bookstore) (.*)(?:\s+(?:at|on|in|by|around)\s+(.+?))?(?:\s|$)/i,
    /(?:meet|hang out|spend time|catch up) (?:with\s+)?(.+?)(?:\s+(?:at|on|in|by|around)\s+(.+?))?(?:\s|$)/i
  ];

  for (const pattern of reminderPatterns) {
    const match = userMessage.match(pattern);
    console.log('🎯 Testing reminder pattern:', pattern.source);
    console.log('🎯 Match result:', match);
    if (match) {
      const title = match[1].trim();
      const timeStr = match[2]?.trim();
      
      console.log('🎯 Creating reminder:', title, 'at time:', timeStr);
      
      try {
        const dueDate = parseTimeString(timeStr) || new Date(Date.now() + 24 * 60 * 60 * 1000); // Default: tomorrow
        
        await storage.createReminder({
          userId: "default-user",
          title: title,
          description: `Auto-created from: "${userMessage}"`,
          dueDate: dueDate,
          fromPipo: true,
          isCompleted: false
        });

        console.log('🎯 Successfully created reminder!');
        creations.push({
          type: 'reminder',
          title: title,
          dueDate: dueDate,
          created: true
        });
        break; // Only create one reminder per message
      } catch (error) {
        console.log('🎯 Error creating reminder:', error);
        creations.push({
          type: 'reminder',
          title: title,
          created: false
        });
      }
    }
  }

  // Detect calendar events - enhanced patterns for better recognition
  const calendarPatterns = [
    /(?:meeting|appointment|event|call|session|interview|conference|presentation)\s+(?:with\s+)?(.+?)(?:\s+(?:at|on|from|starting)\s+(.+?))?(?:\s|$)/i,
    /(?:schedule|book|plan|set up)\s+(?:a\s+)?(.+?)(?:\s+(?:for|on|at|from|starting)\s+(.+?))?(?:\s|$)/i,
    /i have (?:a\s+)?(?:meeting|appointment|event|call|session|interview|conference|presentation|class|lecture)\s*(.*)(?:\s+(?:at|on|from|starting)\s+(.+?))?(?:\s|$)/i,
    /(?:class|lecture|workshop|seminar|training)\s+(?:on\s+|about\s+|for\s+)?(.+?)(?:\s+(?:at|on|from|starting)\s+(.+?))?(?:\s|$)/i,
    // Academic/work patterns
    /(?:exam|test|quiz|midterm|final)\s+(?:for\s+|on\s+|in\s+)?(.+?)(?:\s+(?:at|on|from|starting)\s+(.+?))?(?:\s|$)/i,
    /(?:assignment|homework|project)\s+(?:for\s+|on\s+|in\s+)?(.+?)(?:\s+(?:due|at|on|by)\s+(.+?))?(?:\s|$)/i,
    // Hobby and leisure calendar events
    /(?:basketball|football|soccer|tennis|golf|baseball|volleyball|swimming|running|jogging|cycling|hiking|yoga|gym|workout|exercise)\s+(?:session|practice|game|match|training)?\s*(?:with\s+)?(.*)(?:\s+(?:at|on|from|starting)\s+(.+?))?(?:\s|$)/i,
    /(?:gaming|game)\s+(?:session|night|tournament)?\s+(?:with\s+)?(.+?)(?:\s+(?:at|on|from|starting)\s+(.+?))?(?:\s|$)/i,
    /(?:book club|reading)\s+(?:session|meeting)?\s*(.*)(?:\s+(?:at|on|from|starting)\s+(.+?))?(?:\s|$)/i,
    /(?:coffee|lunch|dinner|brunch)\s+(?:with\s+)?(.+?)(?:\s+(?:at|on|from|starting)\s+(.+?))?(?:\s|$)/i,
    /(?:hangout|hang out|meet up|get together)\s+(?:with\s+)?(.+?)(?:\s+(?:at|on|from|starting)\s+(.+?))?(?:\s|$)/i
  ];

  for (const pattern of calendarPatterns) {
    const match = userMessage.match(pattern);
    console.log('🎯 Testing calendar pattern:', pattern.source);
    console.log('🎯 Calendar match result:', match);
    if (match) {
      const title = match[1].trim();
      const dateStr = match[2]?.trim();
      const timeStr = match[3]?.trim();
      
      console.log('🎯 Creating calendar event:', title, 'at time:', dateStr, timeStr);
      
      try {
        const startTime = parseTimeString(dateStr + ' ' + timeStr) || new Date(Date.now() + 60 * 60 * 1000); // Default: 1 hour from now
        const endTime = new Date(startTime.getTime() + 60 * 60 * 1000); // Default: 1 hour duration
        
        // Create calendar event
        await storage.createCalendarEvent({
          userId: "default-user",
          title: title,
          description: `Auto-created from: "${userMessage}"`,
          startTime: startTime,
          endTime: endTime,
          location: null
        });

        // Also create a corresponding todo item
        await storage.createTodo({
          userId: "default-user",
          title: `Prepare for: ${title}`,
          description: `Auto-created todo for calendar event: "${title}"`,
          priority: "medium",
          isCompleted: false
        });

        console.log('🎯 Successfully created calendar event and todo!');
        creations.push({
          type: 'calendar',
          title: title,
          startTime: startTime,
          endTime: endTime,
          created: true
        });
        break; // Only create one calendar event per message
      } catch (error) {
        console.log('🎯 Error creating calendar event:', error);
        creations.push({
          type: 'calendar',
          title: title,
          created: false
        });
      }
    }
  }

  return creations;
}

function parseTimeString(timeStr?: string): Date | null {
  if (!timeStr) return null;
  
  const now = new Date();
  const lowerTimeStr = timeStr.toLowerCase().trim();
  
  console.log('🎯 Parsing time string:', timeStr);
  
  // Handle specific time formats like "5:30 PM", "10 AM", "2:15 PM"
  const timeRegex = /(\d{1,2}):?(\d{2})?\s*(am|pm)/i;
  const timeMatch = lowerTimeStr.match(timeRegex);
  
  if (timeMatch) {
    const hour = parseInt(timeMatch[1]);
    const minute = parseInt(timeMatch[2] || '0');
    const isPM = timeMatch[3].toLowerCase() === 'pm';
    
    let adjustedHour = hour;
    if (isPM && hour !== 12) {
      adjustedHour += 12;
    } else if (!isPM && hour === 12) {
      adjustedHour = 0;
    }
    
    const timeDate = new Date(now);
    timeDate.setHours(adjustedHour, minute, 0, 0);
    
    // If the time has already passed today, set it for tomorrow
    if (timeDate <= now) {
      timeDate.setDate(timeDate.getDate() + 1);
    }
    
    console.log('🎯 Parsed time:', timeDate);
    return timeDate;
  }
  
  // Handle 24-hour format like "14:30", "09:15"
  const time24Regex = /(\d{1,2}):(\d{2})/;
  const time24Match = lowerTimeStr.match(time24Regex);
  
  if (time24Match) {
    const hour = parseInt(time24Match[1]);
    const minute = parseInt(time24Match[2]);
    
    if (hour >= 0 && hour <= 23 && minute >= 0 && minute <= 59) {
      const timeDate = new Date(now);
      timeDate.setHours(hour, minute, 0, 0);
      
      // If the time has already passed today, set it for tomorrow
      if (timeDate <= now) {
        timeDate.setDate(timeDate.getDate() + 1);
      }
      
      console.log('🎯 Parsed 24h time:', timeDate);
      return timeDate;
    }
  }
  
  // Handle relative times
  if (lowerTimeStr.includes('tomorrow')) {
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(9, 0, 0, 0); // Default to 9 AM
    return tomorrow;
  }
  
  if (lowerTimeStr.includes('next week')) {
    const nextWeek = new Date(now);
    nextWeek.setDate(nextWeek.getDate() + 7);
    nextWeek.setHours(9, 0, 0, 0);
    return nextWeek;
  }

  // Handle day names
  const dayNames = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  for (let i = 0; i < dayNames.length; i++) {
    if (lowerTimeStr.includes(dayNames[i])) {
      const targetDay = new Date(now);
      const daysUntilTarget = (i + 7 - targetDay.getDay()) % 7 || 7;
      targetDay.setDate(targetDay.getDate() + daysUntilTarget);
      targetDay.setHours(9, 0, 0, 0);
      return targetDay;
    }
  }

  // Handle "in X hours/minutes"
  const inTimeRegex = /in\s+(\d+)\s+(hour|hours|minute|minutes)/i;
  const inTimeMatch = lowerTimeStr.match(inTimeRegex);
  
  if (inTimeMatch) {
    const amount = parseInt(inTimeMatch[1]);
    const unit = inTimeMatch[2].toLowerCase();
    const futureTime = new Date(now);
    
    if (unit.includes('hour')) {
      futureTime.setHours(futureTime.getHours() + amount);
    } else if (unit.includes('minute')) {
      futureTime.setMinutes(futureTime.getMinutes() + amount);
    }
    
    return futureTime;
  }

  // Try to parse as a regular date
  try {
    const parsed = new Date(timeStr);
    if (!isNaN(parsed.getTime())) {
      return parsed;
    }
  } catch (error) {
    // Ignore parsing errors
  }
  
  console.log('🎯 Could not parse time string');
  return null;
}

// Function to extract and track names from messages
async function extractAndTrackNames(userMessage: string, userId: string = "default-user") {
  // Common name patterns - look for capitalized words that might be names
  const namePatterns = [
    // Explicit mentions like "with John", "my friend Sarah", "my brother Mike"
    /(?:with|meet|see|call|text|message|visit)\s+([A-Z][a-z]+)/gi,
    /(?:friend|buddy|pal|mate|colleague|coworker|teammate|partner)\s+([A-Z][a-z]+)/gi,
    /(?:brother|sister|mom|dad|mother|father|cousin|uncle|aunt|grandpa|grandma|husband|wife|boyfriend|girlfriend)\s+([A-Z][a-z]+)/gi,
    // Gaming contexts
    /(?:play|game|gaming)\s+(?:with\s+)?([A-Z][a-z]+)/gi,
    // Activity contexts
    /(?:hang out|chill|relax|spend time)\s+(?:with\s+)?([A-Z][a-z]+)/gi,
    // Direct mentions in activities
    /([A-Z][a-z]+)\s+(?:and I|and me)/gi,
    /(?:I and|me and)\s+([A-Z][a-z]+)/gi,
  ];

  const foundNames = new Set<string>();

  // Extract names using patterns
  for (const pattern of namePatterns) {
    let match;
    pattern.lastIndex = 0; // Reset pattern for global search
    while ((match = pattern.exec(userMessage)) !== null) {
      if (match[1]) {
        foundNames.add(match[1]);
      }
    }
  }

  console.log('🎯 Found potential names:', Array.from(foundNames));

  // Process each found name
  const namesArray = Array.from(foundNames);
  for (let i = 0; i < namesArray.length; i++) {
    const name = namesArray[i];
    // Skip common words that aren't names
    const commonWords = ['Today', 'Tomorrow', 'Yesterday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    if (commonWords.includes(name)) {
      continue;
    }

    try {
      // Check if this name already exists
      const existing = await storage.getRecognizedNameByName(userId, name);
      
      if (existing) {
        // Update mention count and context
        const newContext = existing.context ? `${existing.context}; ${userMessage}` : userMessage;
        await storage.updateRecognizedName(existing.id, {
          mentionCount: existing.mentionCount + 1,
          context: newContext.length > 500 ? newContext.substring(0, 500) + '...' : newContext
        });
        console.log('🎯 Updated existing name:', name);
      } else {
        // Create new recognized name
        let relationship = 'unknown';
        const lowerMessage = userMessage.toLowerCase();
        
        // Try to determine relationship from context
        if (lowerMessage.includes('friend') || lowerMessage.includes('buddy')) {
          relationship = 'friend';
        } else if (lowerMessage.includes('family') || lowerMessage.includes('brother') || lowerMessage.includes('sister') || lowerMessage.includes('mom') || lowerMessage.includes('dad')) {
          relationship = 'family';
        } else if (lowerMessage.includes('colleague') || lowerMessage.includes('coworker') || lowerMessage.includes('work')) {
          relationship = 'colleague';
        } else if (lowerMessage.includes('game') || lowerMessage.includes('gaming') || lowerMessage.includes('play')) {
          relationship = 'gaming_friend';
        }

        await storage.createRecognizedName({
          userId,
          name,
          relationship,
          context: userMessage,
          mentionCount: 1
        });
        console.log('🎯 Created new recognized name:', name, 'with relationship:', relationship);
      }
    } catch (error) {
      console.log('🎯 Error processing name:', name, error);
    }
  }

  return Array.from(foundNames);
}

function generatePipoResponse(userMessage: string, autoCreations: AutoCreation[] = []): string {
  const lowerMessage = userMessage.toLowerCase();
  
  // If we created something automatically, acknowledge it
  if (autoCreations.length > 0) {
    const successful = autoCreations.filter(c => c.created);
    if (successful.length > 0) {
      const types = successful.map(c => c.type);
      const reminderCount = types.filter(t => t === 'reminder').length;
      const calendarCount = types.filter(t => t === 'calendar').length;
      
      let response = "Perfect! I've got you covered! 🐧✨ I automatically created ";
      
      if (reminderCount > 0 && calendarCount > 0) {
        response += `${reminderCount} reminder${reminderCount > 1 ? 's' : ''} and ${calendarCount} calendar event${calendarCount > 1 ? 's' : ''} for you! `;
      } else if (reminderCount > 0) {
        response += `${reminderCount} reminder${reminderCount > 1 ? 's' : ''} for you! `;
      } else if (calendarCount > 0) {
        response += `${calendarCount} calendar event${calendarCount > 1 ? 's' : ''} for you! `;
      }
      
      response += "Check your tabs to see them! I love keeping you organized! 📅🔔";
      return response;
    }
  }
  
  // Positive/achievement responses
  if (lowerMessage.includes("promoted") || lowerMessage.includes("achievement") || lowerMessage.includes("success")) {
    return "OMG YES! 🎉 That's INCREDIBLE! You totally deserve it! I'm doing a happy penguin dance right now! 🐧💃 Tell me more about how you're feeling!";
  }
  
  // Sad/difficult responses  
  if (lowerMessage.includes("sad") || lowerMessage.includes("difficult") || lowerMessage.includes("hard")) {
    return "Oh buddy 😞 I can hear that this is tough for you. Remember, I'm here with you through it all! Want to talk more about what's going on? 🐧💙";
  }
  
  // Schedule/calendar related
  if (lowerMessage.includes("appointment") || lowerMessage.includes("meeting") || lowerMessage.includes("schedule")) {
    return "Got it! 📅 I'm always ready to help you stay organized! Tell me more details and I can add it to your calendar automatically! 🐧";
  }
  
  // Todo/task related
  if (lowerMessage.includes("need to") || lowerMessage.includes("have to") || lowerMessage.includes("task")) {
    return "Ooh, sounds important! 📝 Want me to help you remember that? Just say 'remind me to...' and I'll take care of it! 🐧✨";
  }
  
  // Default friendly responses
  const responses = [
    "That's so interesting! 🐧 Tell me more about that - I love hearing what's on your mind!",
    "Wow, thanks for sharing that with me! 💙 How are you feeling about it?",
    "I'm so glad you're journaling with me today! 🐧 What else is happening in your world?",
    "That sounds important to you! ✨ Want to dive deeper into that thought?",
    "I love our chats! 🐧💙 Keep going - I'm all flippers! 👂"
  ];
  
  return responses[Math.floor(Math.random() * responses.length)];
}
