import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { User } from "@shared/schema";
import BottomNavigation from "@/components/BottomNavigation";
import ChatTab from "@/components/ChatTab";
import RemindersTab from "@/components/RemindersTab";
import CalendarTab from "@/components/CalendarTab";
import TodoTab from "@/components/TodoTab";
import AccountTab from "@/components/AccountTab";

type TabType = "chat" | "reminders" | "calendar" | "todos" | "account";

export default function Home() {
  const [activeTab, setActiveTab] = useState<TabType>("chat");

  const { data: user, isLoading } = useQuery<User>({
    queryKey: ["/api/user/current"],
  });

  if (isLoading) {
    return (
      <div className="max-w-md mx-auto bg-white shadow-2xl rounded-t-3xl min-h-screen relative overflow-hidden">
        <div className="flex items-center justify-center h-screen">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  const renderTab = () => {
    switch (activeTab) {
      case "chat":
        return <ChatTab user={user} />;
      case "reminders":
        return <RemindersTab />;
      case "calendar":
        return <CalendarTab />;
      case "todos":
        return <TodoTab />;
      case "account":
        return <AccountTab user={user} />;
      default:
        return <ChatTab user={user} />;
    }
  };

  return (
    <div className="max-w-md mx-auto bg-white shadow-2xl rounded-t-3xl min-h-screen relative overflow-hidden" data-testid="main-app-container">
      {renderTab()}
      <BottomNavigation activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  );
}
