import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { Todo } from "@shared/schema";
import PipoMascot from "./PipoMascot";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { format } from "date-fns";
import { CheckCircle2, Circle, ListTodo } from "lucide-react";

export default function TodoTab() {
  const { data: todos, isLoading } = useQuery<Todo[]>({
    queryKey: ["/api/todos"],
  });

  const updateTodoMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: Partial<Todo> }) => {
      const response = await apiRequest("PATCH", `/api/todos/${id}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/todos"] });
    },
  });

  const handleToggleComplete = (todo: Todo) => {
    updateTodoMutation.mutate({
      id: todo.id,
      updates: { isCompleted: !todo.isCompleted }
    });
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "destructive";
      case "medium":
        return "secondary";
      case "low":
        return "outline";
      default:
        return "outline";
    }
  };

  const getPriorityLabel = (priority: string) => {
    switch (priority) {
      case "high":
        return "🔥 High";
      case "medium":
        return "⚡ Medium";
      case "low":
        return "💤 Low";
      default:
        return "Medium";
    }
  };

  if (isLoading) {
    return (
      <div className="flex-1 p-4 pt-16">
        <div className="animate-pulse space-y-4">
          <div className="h-4 bg-muted rounded w-3/4"></div>
          <div className="h-4 bg-muted rounded w-1/2"></div>
        </div>
      </div>
    );
  }

  const activeTodos = todos?.filter(t => !t.isCompleted) || [];
  const completedTodos = todos?.filter(t => t.isCompleted) || [];

  return (
    <div className="pb-20" data-testid="todo-tab">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary to-accent p-4 pt-12 text-white">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center penguin-float">
            <PipoMascot size="medium" expression="happy" />
          </div>
          <div>
            <h1 className="text-xl font-bold" data-testid="todo-title">Your Tasks 📝</h1>
            <p className="text-primary-foreground/80 text-sm">Let's get things done together!</p>
          </div>
        </div>
      </div>

      <div className="p-4 space-y-6">
        {/* Active Todos */}
        {activeTodos.length > 0 && (
          <div>
            <h2 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
              <ListTodo className="w-5 h-5 text-primary" />
              To Do ({activeTodos.length})
            </h2>
            <div className="space-y-3">
              {activeTodos.map((todo) => (
                <div 
                  key={todo.id} 
                  className="bg-card border border-border rounded-lg p-4"
                  data-testid={`todo-${todo.id}`}
                >
                  <div className="flex items-start gap-3">
                    <button
                      onClick={() => handleToggleComplete(todo)}
                      disabled={updateTodoMutation.isPending}
                      className="mt-0.5 text-muted-foreground hover:text-primary transition-colors"
                      data-testid={`button-toggle-${todo.id}`}
                    >
                      <Circle className="w-5 h-5" />
                    </button>
                    
                    <div className="flex-1">
                      <h3 className="font-medium text-foreground mb-1" data-testid="todo-title-text">
                        {todo.title}
                      </h3>
                      {todo.description && (
                        <p className="text-sm text-muted-foreground mb-2" data-testid="todo-description">
                          {todo.description}
                        </p>
                      )}
                      <div className="flex items-center gap-2">
                        <Badge variant={getPriorityColor(todo.priority)}>
                          {getPriorityLabel(todo.priority)}
                        </Badge>
                        <span className="text-xs text-muted-foreground" data-testid="todo-created-date">
                          Created {format(new Date(todo.createdAt), "MMM d")}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Completed Todos */}
        {completedTodos.length > 0 && (
          <div>
            <h2 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-green-500" />
              Completed ({completedTodos.length})
            </h2>
            <div className="space-y-3">
              {completedTodos.map((todo) => (
                <div 
                  key={todo.id} 
                  className="bg-muted/50 border border-border rounded-lg p-4 opacity-75"
                  data-testid={`completed-todo-${todo.id}`}
                >
                  <div className="flex items-start gap-3">
                    <button
                      onClick={() => handleToggleComplete(todo)}
                      disabled={updateTodoMutation.isPending}
                      className="mt-0.5 text-green-500 hover:text-green-600 transition-colors"
                      data-testid={`button-uncomplete-${todo.id}`}
                    >
                      <CheckCircle2 className="w-5 h-5" />
                    </button>
                    
                    <div className="flex-1">
                      <h3 className="font-medium text-foreground mb-1 line-through">
                        {todo.title}
                      </h3>
                      {todo.description && (
                        <p className="text-sm text-muted-foreground mb-2 line-through">
                          {todo.description}
                        </p>
                      )}
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="opacity-50">
                          Completed ✓
                        </Badge>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Empty State */}
        {(!todos || todos.length === 0) && (
          <div className="text-center py-12" data-testid="empty-todos">
            <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <PipoMascot size="medium" expression="neutral" />
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-2">No tasks yet!</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Chat with me to create tasks! I'll help you stay productive! 🐧✅
            </p>
          </div>
        )}

        {/* All tasks completed */}
        {todos && todos.length > 0 && activeTodos.length === 0 && (
          <div className="text-center py-12" data-testid="all-todos-complete">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <PipoMascot size="medium" expression="excited" />
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-2">All tasks completed! 🎉</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Great job! You've completed all your tasks! I'm so proud of you! 🐧✨
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
