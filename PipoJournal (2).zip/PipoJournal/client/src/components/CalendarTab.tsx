import { useQuery } from "@tanstack/react-query";
import { CalendarEvent } from "@shared/schema";
import PipoMascot from "./PipoMascot";
import { Badge } from "@/components/ui/badge";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isSameDay, isToday } from "date-fns";
import { Calendar, MapPin } from "lucide-react";
import { useState } from "react";

export default function CalendarTab() {
  const [selectedDate, setSelectedDate] = useState(new Date());
  
  const { data: events, isLoading } = useQuery<CalendarEvent[]>({
    queryKey: ["/api/calendar/events"],
  });

  if (isLoading) {
    return (
      <div className="flex-1 p-4 pt-16">
        <div className="animate-pulse space-y-4">
          <div className="h-4 bg-muted rounded w-3/4"></div>
          <div className="h-4 bg-muted rounded w-1/2"></div>
        </div>
      </div>
    );
  }

  const monthStart = startOfMonth(selectedDate);
  const monthEnd = endOfMonth(selectedDate);
  const monthDays = eachDayOfInterval({ start: monthStart, end: monthEnd });

  const eventsForDate = (date: Date) => {
    return events?.filter(event => 
      isSameDay(new Date(event.startTime), date)
    ) || [];
  };

  const todaysEvents = eventsForDate(new Date());
  const selectedDateEvents = eventsForDate(selectedDate);

  return (
    <div className="pb-20" data-testid="calendar-tab">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary to-accent p-4 pt-12 text-white">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center penguin-float">
            <PipoMascot size="medium" expression="happy" />
          </div>
          <div>
            <h1 className="text-xl font-bold" data-testid="calendar-title">Your Calendar 📅</h1>
            <p className="text-primary-foreground/80 text-sm">Let me help you stay organized!</p>
          </div>
        </div>
      </div>

      <div className="p-4 space-y-6">
        {/* Mini Calendar */}
        <div className="bg-card border border-border rounded-lg p-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-foreground">
              {format(selectedDate, "MMMM yyyy")}
            </h2>
          </div>
          
          <div className="grid grid-cols-7 gap-1 mb-2">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
              <div key={day} className="text-center text-xs font-medium text-muted-foreground p-2">
                {day}
              </div>
            ))}
          </div>
          
          <div className="grid grid-cols-7 gap-1">
            {monthDays.map((day) => {
              const dayEvents = eventsForDate(day);
              const hasEvents = dayEvents.length > 0;
              const isSelected = isSameDay(day, selectedDate);
              const isCurrentMonth = isSameMonth(day, selectedDate);
              const isCurrentDay = isToday(day);

              return (
                <button
                  key={day.toISOString()}
                  onClick={() => setSelectedDate(day)}
                  className={`
                    relative p-2 text-sm rounded-lg transition-colors
                    ${isSelected ? 'bg-primary text-primary-foreground' : ''}
                    ${isCurrentDay && !isSelected ? 'bg-secondary text-secondary-foreground font-bold' : ''}
                    ${!isCurrentMonth ? 'text-muted-foreground/50' : 'text-foreground'}
                    ${hasEvents && !isSelected ? 'bg-accent/20' : ''}
                    hover:bg-muted
                  `}
                  data-testid={`calendar-day-${format(day, 'yyyy-MM-dd')}`}
                >
                  {format(day, 'd')}
                  {hasEvents && (
                    <div className="absolute bottom-1 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-primary rounded-full"></div>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Today's Events */}
        {isToday(selectedDate) && todaysEvents.length > 0 && (
          <div>
            <h2 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-primary" />
              Today's Events
            </h2>
            <div className="space-y-3">
              {todaysEvents.map((event) => (
                <div key={event.id} className="bg-card border border-border rounded-lg p-4" data-testid={`event-${event.id}`}>
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <h3 className="font-medium text-foreground mb-1" data-testid="event-title">
                        {event.title}
                      </h3>
                      {event.description && (
                        <p className="text-sm text-muted-foreground mb-2">
                          {event.description}
                        </p>
                      )}
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge variant="outline">
                          {format(new Date(event.startTime), "h:mm a")} - {format(new Date(event.endTime), "h:mm a")}
                        </Badge>
                        {event.location && (
                          <Badge variant="secondary" className="flex items-center gap-1">
                            <MapPin className="w-3 h-3" />
                            {event.location}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Selected Date Events */}
        {!isToday(selectedDate) && selectedDateEvents.length > 0 && (
          <div>
            <h2 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-primary" />
              Events for {format(selectedDate, "MMM d, yyyy")}
            </h2>
            <div className="space-y-3">
              {selectedDateEvents.map((event) => (
                <div key={event.id} className="bg-card border border-border rounded-lg p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <h3 className="font-medium text-foreground mb-1">
                        {event.title}
                      </h3>
                      {event.description && (
                        <p className="text-sm text-muted-foreground mb-2">
                          {event.description}
                        </p>
                      )}
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge variant="outline">
                          {format(new Date(event.startTime), "h:mm a")} - {format(new Date(event.endTime), "h:mm a")}
                        </Badge>
                        {event.location && (
                          <Badge variant="secondary" className="flex items-center gap-1">
                            <MapPin className="w-3 h-3" />
                            {event.location}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Empty State */}
        {(!events || events.length === 0) && (
          <div className="text-center py-12" data-testid="empty-calendar">
            <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <PipoMascot size="medium" expression="neutral" />
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-2">No events yet!</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Chat with me to add events to your calendar! I'll help you stay organized! 🐧📅
            </p>
          </div>
        )}

        {/* No Events for Selected Date */}
        {events && events.length > 0 && selectedDateEvents.length === 0 && !isToday(selectedDate) && (
          <div className="text-center py-8" data-testid="no-events-selected-date">
            <div className="w-12 h-12 bg-muted rounded-full flex items-center justify-center mx-auto mb-3">
              <PipoMascot size="small" expression="neutral" />
            </div>
            <p className="text-sm text-muted-foreground">
              No events scheduled for {format(selectedDate, "MMM d, yyyy")}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
