import { User } from "@shared/schema";
import PipoMascot from "./PipoMascot";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { Flame, Calendar, Trophy, Settings } from "lucide-react";

interface AccountTabProps {
  user?: User;
}

export default function AccountTab({ user }: AccountTabProps) {
  const getUserInitials = (name?: string) => {
    if (!name) return "U";
    return name
      .split(" ")
      .map(n => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  const getStreakMessage = (streak: number) => {
    if (streak === 0) return "Let's start your streak today! 🐧";
    if (streak === 1) return "Great start, buddy! 🎉";
    if (streak < 7) return "Keep it going! 💪";
    if (streak < 30) return "You're on fire! 🔥";
    return "Incredible dedication! 🏆";
  };

  const getStreakColor = (streak: number) => {
    if (streak === 0) return "text-muted-foreground";
    if (streak < 7) return "text-orange-500";
    if (streak < 30) return "text-red-500";
    return "text-purple-500";
  };

  return (
    <div className="pb-20" data-testid="account-tab">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary to-accent p-4 pt-12 text-white">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center penguin-float">
            <PipoMascot size="medium" expression="happy" />
          </div>
          <div>
            <h1 className="text-xl font-bold" data-testid="account-title">Your Profile 👤</h1>
            <p className="text-primary-foreground/80 text-sm">You're amazing, buddy!</p>
          </div>
        </div>
      </div>

      <div className="p-4 space-y-6">
        {/* User Profile Card */}
        <Card>
          <CardContent className="pt-6">
            <div className="text-center mb-6">
              <div className="w-20 h-20 bg-gradient-to-br from-primary to-accent rounded-full mx-auto mb-3 flex items-center justify-center">
                <span className="text-2xl text-white font-bold" data-testid="user-initials-large">
                  {getUserInitials(user?.name)}
                </span>
              </div>
              <h2 className="text-xl font-bold text-foreground mb-1" data-testid="user-name">
                {user?.name || "User"}
              </h2>
              <p className="text-sm text-muted-foreground" data-testid="join-date">
                Journaling since {user?.createdAt ? format(new Date(user.createdAt), "MMMM yyyy") : "recently"}
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Streak Card */}
        <Card className="bg-gradient-to-r from-primary to-accent">
          <CardContent className="pt-6 text-white text-center">
            <div className="mb-4">
              <div className={`text-6xl font-bold mb-2 ${getStreakColor(user?.streak || 0)}`} data-testid="streak-display">
                {user?.streak || 0}
              </div>
              <div className="text-lg font-semibold mb-1">Day Streak! 🔥</div>
              <div className="text-sm opacity-80" data-testid="streak-message">
                {getStreakMessage(user?.streak || 0)}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-4">
          <Card>
            <CardContent className="pt-4 text-center">
              <div className="flex items-center justify-center w-12 h-12 bg-primary/10 rounded-full mx-auto mb-3">
                <Flame className="w-6 h-6 text-primary" />
              </div>
              <div className="text-2xl font-bold text-foreground mb-1" data-testid="total-journals">
                {user?.streak || 0}
              </div>
              <div className="text-sm text-muted-foreground">Journal Entries</div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-4 text-center">
              <div className="flex items-center justify-center w-12 h-12 bg-accent/10 rounded-full mx-auto mb-3">
                <Calendar className="w-6 h-6 text-accent" />
              </div>
              <div className="text-2xl font-bold text-foreground mb-1" data-testid="days-active">
                {user?.streak || 0}
              </div>
              <div className="text-sm text-muted-foreground">Days Active</div>
            </CardContent>
          </Card>
        </div>

        {/* Achievement Badges */}
        <Card>
          <CardContent className="pt-6">
            <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
              <Trophy className="w-5 h-5 text-yellow-500" />
              Achievements
            </h3>
            <div className="grid grid-cols-2 gap-3">
              {(user?.streak || 0) >= 1 && (
                <Badge variant="secondary" className="justify-center p-3">
                  🎯 First Entry
                </Badge>
              )}
              {(user?.streak || 0) >= 3 && (
                <Badge variant="secondary" className="justify-center p-3">
                  🔥 3 Day Streak
                </Badge>
              )}
              {(user?.streak || 0) >= 7 && (
                <Badge variant="secondary" className="justify-center p-3">
                  ⭐ Week Warrior
                </Badge>
              )}
              {(user?.streak || 0) >= 30 && (
                <Badge variant="secondary" className="justify-center p-3">
                  🏆 Month Master
                </Badge>
              )}
            </div>
            
            {(user?.streak || 0) === 0 && (
              <div className="text-center py-8" data-testid="no-achievements">
                <PipoMascot size="medium" expression="neutral" className="mx-auto mb-3" />
                <p className="text-sm text-muted-foreground">
                  Start journaling to earn your first achievement! 🐧✨
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Settings */}
        <Card>
          <CardContent className="pt-6">
            <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
              <Settings className="w-5 h-5 text-muted-foreground" />
              Settings
            </h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                <span className="text-sm text-foreground">Pipo Check-ins</span>
                <Badge variant="outline">Daily</Badge>
              </div>
              <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                <span className="text-sm text-foreground">Voice Recording</span>
                <Badge variant="outline">Enabled</Badge>
              </div>
              <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                <span className="text-sm text-foreground">Calendar Sync</span>
                <Badge variant="outline">Google</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Pipo Message */}
        <Card className="bg-secondary/20 border-secondary/50">
          <CardContent className="pt-6">
            <div className="flex items-start gap-3">
              <PipoMascot size="small" expression="happy" className="flex-shrink-0 mt-1" />
              <div>
                <p className="text-sm text-foreground font-medium mb-2">
                  A note from Pipo 🐧
                </p>
                <p className="text-sm text-muted-foreground">
                  You're doing great, buddy! Remember, I'm here whenever you need to chat, plan, or just share what's on your mind. Keep being awesome! 💙
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
