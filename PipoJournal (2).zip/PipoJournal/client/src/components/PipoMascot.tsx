import pipoImage from "@assets/Screenshot_2025-09-08-20-34-41-80_99c04817c0de5652397fc8b56c3b3817_1757338496783.jpg";

interface PipoMascotProps {
  size?: "small" | "medium" | "large";
  expression?: "happy" | "excited" | "neutral" | "concerned";
  className?: string;
}

export default function PipoMascot({ 
  size = "medium", 
  expression = "happy", 
  className = "" 
}: PipoMascotProps) {
  const sizeClasses = {
    small: "w-6 h-6",
    medium: "w-10 h-10",
    large: "w-16 h-16",
  };

  // Get the appropriate Pipo image based on expression
  const getPipoImage = () => {
    // For now, we'll use the main Pipo image for all expressions
    // You could crop different expressions from the image if needed
    return pipoImage;
  };

  return (
    <div className={`${sizeClasses[size]} ${className}`} data-testid="pipo-mascot">
      <img 
        src={getPipoImage()} 
        alt="Pipo the penguin" 
        className="w-full h-full object-contain rounded-full"
      />
    </div>
  );
}
