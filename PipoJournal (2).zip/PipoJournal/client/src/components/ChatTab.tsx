import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { ChatMessage, User } from "@shared/schema";
import PipoMascot from "./PipoMascot";
import VoiceInput from "./VoiceInput";
import { Button } from "@/components/ui/button";

interface ChatTabProps {
  user?: User;
}

export default function ChatTab({ user }: ChatTabProps) {
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const { data: messages, isLoading } = useQuery<ChatMessage[]>({
    queryKey: ["/api/chat/messages"],
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      const response = await apiRequest("POST", "/api/chat/messages", {
        content,
        isFromPipo: false,
        messageType: "text",
      });
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/chat/messages"] });
      
      // If auto-creations happened, refresh those tabs too
      if (data.autoCreations && data.autoCreations.length > 0) {
        const hasReminders = data.autoCreations.some((c: any) => c.type === 'reminder' && c.created);
        const hasCalendar = data.autoCreations.some((c: any) => c.type === 'calendar' && c.created);
        
        if (hasReminders) {
          queryClient.invalidateQueries({ queryKey: ["/api/reminders"] });
        }
        if (hasCalendar) {
          queryClient.invalidateQueries({ queryKey: ["/api/calendar/events"] });
          // Calendar events now also create todos, so refresh todos too
          queryClient.invalidateQueries({ queryKey: ["/api/todos"] });
        }
      }
    },
  });

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (content: string) => {
    if (!content.trim()) return;
    
    setIsTyping(true);
    try {
      await sendMessageMutation.mutateAsync(content);
    } finally {
      setIsTyping(false);
    }
  };

  const getUserInitials = (name?: string) => {
    if (!name) return "U";
    return name
      .split(" ")
      .map(n => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  if (isLoading) {
    return (
      <div className="flex-1 p-4">
        <div className="animate-pulse space-y-4">
          <div className="h-4 bg-muted rounded w-3/4"></div>
          <div className="h-4 bg-muted rounded w-1/2"></div>
        </div>
      </div>
    );
  }

  return (
    <>
      {/* Header */}
      <div className="bg-gradient-to-r from-primary to-accent p-4 pt-12 text-white relative" data-testid="chat-header">
        <div className="absolute top-4 right-4">
          <div className="bg-secondary text-secondary-foreground px-3 py-1 rounded-full text-sm font-semibold flex items-center gap-1">
            <span className="text-orange-500">🔥</span>
            <span data-testid="streak-count">{user?.streak || 0}</span> days
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center penguin-float">
            <PipoMascot size="medium" expression="happy" />
          </div>
          <div>
            <h1 className="text-xl font-bold" data-testid="greeting-text">Hi there! 👋</h1>
            <p className="text-primary-foreground/80 text-sm">Ready to chat with Pipo?</p>
          </div>
        </div>
      </div>

      {/* Chat Container */}
      <div className="flex-1 p-4 pb-32 space-y-4 max-h-96 overflow-y-auto" data-testid="chat-container">
        {messages?.map((message) => (
          <div 
            key={message.id} 
            className={`chat-bubble flex items-start gap-3 ${!message.isFromPipo ? 'justify-end' : ''}`}
            data-testid={`message-${message.isFromPipo ? 'pipo' : 'user'}`}
          >
            {message.isFromPipo && (
              <PipoMascot size="small" expression="happy" className="flex-shrink-0" />
            )}
            
            <div className={`p-3 rounded-2xl max-w-xs ${
              message.isFromPipo 
                ? 'bg-muted rounded-tl-sm' 
                : 'bg-primary text-primary-foreground rounded-tr-sm'
            }`}>
              <p className="text-sm" data-testid="message-content">{message.content}</p>
            </div>

            {!message.isFromPipo && (
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-full flex-shrink-0 flex items-center justify-center">
                <span className="text-xs text-white font-semibold" data-testid="user-initials">
                  {getUserInitials(user?.name)}
                </span>
              </div>
            )}
          </div>
        ))}

        {isTyping && (
          <div className="chat-bubble flex items-start gap-3">
            <PipoMascot size="small" expression="neutral" className="flex-shrink-0" />
            <div className="bg-muted p-3 rounded-2xl rounded-tl-sm">
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Voice Input Area */}
      <VoiceInput 
        onSendMessage={handleSendMessage} 
        isLoading={sendMessageMutation.isPending}
      />
    </>
  );
}
