import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Mic, MicOff, Keyboard, Send } from "lucide-react";
import useSpeechRecognition from "@/hooks/useSpeechRecognition";

interface VoiceInputProps {
  onSendMessage: (content: string) => void;
  isLoading?: boolean;
}

export default function VoiceInput({ onSendMessage, isLoading }: VoiceInputProps) {
  const [textInput, setTextInput] = useState("");
  const [isKeyboardMode, setIsKeyboardMode] = useState(false);
  
  const {
    isListening,
    transcript,
    startListening,
    stopListening,
    resetTranscript,
    browserSupportsSpeechRecognition
  } = useSpeechRecognition();

  const handleVoiceToggle = () => {
    if (isListening) {
      stopListening();
    } else {
      resetTranscript();
      startListening();
    }
  };

  const handleSendVoice = () => {
    if (transcript.trim()) {
      onSendMessage(transcript);
      resetTranscript();
      stopListening();
    }
  };

  const handleSendText = () => {
    if (textInput.trim()) {
      onSendMessage(textInput);
      setTextInput("");
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendText();
    }
  };

  return (
    <div className="absolute bottom-20 left-0 right-0 p-4" data-testid="voice-input-area">
      <div className="bg-white border-2 border-border rounded-full p-2 shadow-lg">
        {isKeyboardMode ? (
          <div className="flex items-center gap-2">
            <Input
              value={textInput}
              onChange={(e) => setTextInput(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type your message..."
              className="flex-1 border-0 focus-visible:ring-0 text-sm"
              disabled={isLoading}
              data-testid="text-input"
            />
            <Button
              size="sm"
              onClick={handleSendText}
              disabled={!textInput.trim() || isLoading}
              data-testid="button-send-text"
            >
              <Send className="w-4 h-4" />
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setIsKeyboardMode(false)}
              data-testid="button-switch-voice"
            >
              <Mic className="w-4 h-4" />
            </Button>
          </div>
        ) : (
          <div className="flex items-center gap-3">
            {browserSupportsSpeechRecognition ? (
              <>
                <Button
                  size="lg"
                  onClick={handleVoiceToggle}
                  disabled={isLoading}
                  className={`w-12 h-12 rounded-full ${isListening ? 'bg-red-500 hover:bg-red-600 pulse-mic' : 'bg-primary hover:bg-primary/90'}`}
                  data-testid="button-voice-toggle"
                >
                  {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                </Button>
                <div className="flex-1 text-muted-foreground text-sm">
                  {isListening ? (
                    <div className="flex items-center gap-2">
                      <span className="text-red-500 font-medium">Listening...</span>
                      {transcript && (
                        <Button
                          size="sm"
                          onClick={handleSendVoice}
                          className="ml-2"
                          data-testid="button-send-voice"
                        >
                          Send
                        </Button>
                      )}
                    </div>
                  ) : transcript ? (
                    <div className="flex items-center gap-2">
                      <span className="text-foreground">{transcript}</span>
                      <Button
                        size="sm"
                        onClick={handleSendVoice}
                        data-testid="button-send-transcript"
                      >
                        Send
                      </Button>
                    </div>
                  ) : (
                    <span data-testid="voice-prompt">Tap mic to start journaling...</span>
                  )}
                </div>
              </>
            ) : (
              <div className="flex-1 text-center text-muted-foreground text-sm">
                Speech recognition not supported
              </div>
            )}
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setIsKeyboardMode(true)}
              className="w-8 h-8"
              data-testid="button-switch-keyboard"
            >
              <Keyboard className="w-4 h-4" />
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
